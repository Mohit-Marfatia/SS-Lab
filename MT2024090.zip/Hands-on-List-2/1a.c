/*
============================================================================
Name : 1a.c
Author : Mohit Marfatia
Description : Write a separate program (for each time domain) to set a interval timer in 10sec and 10 micro second
a. ITIMER_REAL
Date: 12th Sept, 2024.
============================================================================
*/

#include<stdio.h>
#include<sys/time.h>
#include<signal.h>

void timerHandler(){
    printf("Timer has expired.\n");
}

int main(void) {
    struct itimerval timer;
	signal(SIGALRM, timerHandler);

    timer.it_value.tv_sec = 10;
    timer.it_value.tv_usec = 10;

    timer.it_interval.tv_sec = 10;
    timer.it_interval.tv_usec = 10;

    int setITimer = setitimer(ITIMER_REAL, &timer, NULL);
    if(setITimer == -1){
        perror("Set ITIMER_REAL:");
    }

    while(1);
	return 0;
}

/*
Output:
Timer has expired.
Timer has expired.
Timer has expired.
Timer has expired.
^C

*/